package com.application.unicorn.exam5ver;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;


public class AppLayout extends ActionBarActivity {

    //private String[] selectCourse;
    public static String course;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);

        getSupportActionBar().hide();

        TextView textView1 = (TextView)findViewById(R.id.title);
        Typeface typeface1 = Typeface.createFromAsset(getAssets(), "fonts/moonhouse.ttf");
        textView1.setTypeface(typeface1);

        TextView textView2 = (TextView)findViewById(R.id.text1);
        Typeface typeface2 = Typeface.createFromAsset(getAssets(), "fonts/BTTTRIAL.ttf");
        textView2.setTypeface(typeface2);

        TextView textView3 = (TextView)findViewById(R.id.text2);
        Typeface typeface3 = Typeface.createFromAsset(getAssets(), "fonts/BTTTRIAL.ttf");
        textView3.setTypeface(typeface3);


        //selectCourse = getResources().getStringArray(R.array.courseList);

        //final Spinner dropdown1 = (Spinner)findViewById(R.id.sub_spinner1);
        //ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, selectCourse);
        //dropdown1.setAdapter(adapter1);
        //ArrayAdapter<CharSequence> coursefont = ArrayAdapter.createFromResource(this, R.array.courseList, R.layout.spinner_item_style);
        //coursefont.setDropDownViewResource(R.layout.spinner_item_style);
        //dropdown1.setAdapter(coursefont);

       // dropdown1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            //@Override
            //public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

               //course = dropdown1.getSelectedItem().toString();

            //}

            //@Override
            //public void onNothingSelected(AdapterView<?> parent) {
            //}
        //});

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_app_layout, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void SelectBE(View view){

        //if("B.E.".equals(course))
            Intent intend = new Intent(this, BePage.class);
            //intend.putExtra("course1", course);
            this.startActivity(intend);

    }

    public void SelectDip(View view){
        Intent intent = new Intent(this, DipPage.class);
        this.startActivity(intent);
    }

 }


