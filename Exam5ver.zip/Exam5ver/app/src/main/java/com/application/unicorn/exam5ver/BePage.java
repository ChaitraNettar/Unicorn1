package com.application.unicorn.exam5ver;


import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;


public class BePage extends ActionBarActivity implements OnItemSelectedListener {

    int resID;
    public String compSub;
    public String branch;
    public String semester;
    public String subject;
    public String year;
    //public String course2;
    public Spinner dropdown1;
    public Spinner dropdown2;
    public Spinner dropdown3;
    public Spinner dropdown4;
    private String[] selectBranch;
    private String[] selectSemester;
    private String[] selectSubject;
    private String[] selectYear;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.be_page);

        getSupportActionBar().hide();

        TextView textView1 = (TextView)findViewById(R.id.title);
        Typeface typeface1 = Typeface.createFromAsset(getAssets(), "fonts/moonhouse.ttf");
        textView1.setTypeface(typeface1);

        Intent intent = getIntent();
        //course2 = intent.getStringExtra("course1");

        selectBranch = getResources().getStringArray(R.array.branchList);
        selectSemester = getResources().getStringArray(R.array.semesterList);
        selectYear = getResources().getStringArray(R.array.yearList);


        dropdown1 = (Spinner)findViewById(R.id.sub_spinner1);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, selectBranch);
        dropdown1.setAdapter(adapter1);
        ArrayAdapter<CharSequence> branchfont = ArrayAdapter.createFromResource(this, R.array.branchList, R.layout.spinner_item_style);
        branchfont.setDropDownViewResource(R.layout.spinner_item_style);
        dropdown1.setAdapter(branchfont);

        dropdown2 = (Spinner)findViewById(R.id.sub_spinner2);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, selectSemester);
        dropdown2.setAdapter(adapter2);
        ArrayAdapter<CharSequence> semesterfont = ArrayAdapter.createFromResource(this, R.array.semesterList, R.layout.spinner_item_style);
        semesterfont.setDropDownViewResource(R.layout.spinner_item_style);
        dropdown2.setAdapter(semesterfont);

        dropdown1.setOnItemSelectedListener(this);
        dropdown2.setOnItemSelectedListener(this);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        branch = dropdown1.getSelectedItem().toString();
        semester = dropdown2.getSelectedItem().toString();

        compSub = branch+"_"+semester;

        if (compSub.matches("EC_THIRD")){
            resID = R.array.EC_THIRD;
        }else if (compSub.equals("EC_FOURTH")){
            resID = R.array.EC_FOURTH;
        }else if (compSub.equals("EC_FIFTH")){
            resID = R.array.EC_FIFTH;
        }else if (compSub.equals("EC_SIXTH")){
            resID = R.array.EC_SIXTH;
        }else if (compSub.equals("EC_SEVENTH")){
            resID = R.array.EC_SEVENTH;
        }else if (compSub.equals("EC_EIGHTH")){
            resID = R.array.EC_EIGHTH;
        }else if (compSub.equals("EE_THIRD")){
            resID = R.array.EE_THIRD;
        }else if (compSub.equals("EE_FOURTH")){
            resID = R.array.EE_FOURTH;
        }else if (compSub.equals("EE_FIFTH")){
            resID = R.array.EE_FIFTH;
        }else if (compSub.equals("EE_SIXTH")){
            resID = R.array.EE_SIXTH;
        }else if (compSub.equals("EE_SEVENTH")){
            resID = R.array.EE_SEVENTH;
        }else if (compSub.equals("EE_EIGHTH")){
            resID = R.array.EE_EIGHTH;
        }else if (compSub.equals("TE_THIRD")){
            resID = R.array.TE_THIRD;
        }else if (compSub.equals("TE_FOURTH")){
            resID = R.array.TE_FOURTH;
        }else if (compSub.equals("TE_FIFTH")){
            resID = R.array.TE_FIFTH;
        }else if (compSub.equals("TE_SIXTH")){
            resID = R.array.TE_SIXTH;
        }else if (compSub.equals("TE_SEVENTH")){
            resID = R.array.TE_SEVENTH;
        }else if (compSub.equals("TE_EIGHTH")){
            resID = R.array.TE_EIGHTH;
        }else if (compSub.equals("CS_THIRD")){
            resID = R.array.CS_THIRD;
        }else if (compSub.equals("CS_FOURTH")){
            resID = R.array.CS_FOURTH;
        }else if (compSub.equals("CS_FIFTH")){
            resID = R.array.CS_FIFTH;
        }else if (compSub.equals("CS_SIXTH")){
            resID = R.array.CS_SIXTH;
        }else if (compSub.equals("CS_SEVENTH")){
            resID = R.array.CS_SEVENTH;
        }else if (compSub.equals("CS_EIGHTH")){
            resID = R.array.CS_EIGHTH;
        }else if (compSub.equals("IS_THIRD")){
            resID = R.array.IS_THIRD;
        }else if (compSub.equals("IS_FOURTH")){
            resID = R.array.IS_FOURTH;
        }else if (compSub.equals("IS_FIFTH")){
            resID = R.array.IS_FIFTH;
        }else if (compSub.equals("IS_SIXTH")){
            resID = R.array.IS_SIXTH;
        }else if (compSub.equals("IS_SEVENTH")){
            resID = R.array.IS_SEVENTH;
        }else if (compSub.equals("IS_EIGHTH")){
            resID = R.array.IS_EIGHTH;
        }else if (compSub.equals("ME_THIRD")){
            resID = R.array.ME_THIRD;
        }else if (compSub.equals("ME_FOURTH")){
            resID = R.array.ME_FOURTH;
        }else if (compSub.equals("ME_FIFTH")){
            resID = R.array.ME_FIFTH;
        }else if (compSub.equals("ME_SIXTH")){
            resID = R.array.ME_SIXTH;
        }else if (compSub.equals("ME_SEVENTH")){
            resID = R.array.ME_SEVENTH;
        }else if (compSub.equals("ME_EIGHTH")){
            resID = R.array.ME_EIGHTH;
        }else if (compSub.equals("CV_THIRD")){
            resID = R.array.CV_THIRD;
        }else if (compSub.equals("CV_FOURTH")){
            resID = R.array.CV_FOURTH;
        }else if (compSub.equals("CV_FIFTH")){
            resID = R.array.CV_FIFTH;
        }else if (compSub.equals("CV_SIXTH")){
            resID = R.array.CV_SIXTH;
        }else if (compSub.equals("CV_SEVENTH")){
            resID = R.array.CV_SEVENTH;
        }else if (compSub.equals("CV_EIGHTH")){
            resID = R.array.CV_EIGHTH;
        }else if (compSub.equals("BT_THIRD")) {
        }
        selectSubject = getResources().getStringArray(resID);

        dropdown3 = (Spinner)findViewById(R.id.sub_spinner3);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, selectSubject);
        dropdown3.setAdapter(adapter3);
        ArrayAdapter<CharSequence> subjectfont = ArrayAdapter.createFromResource(this, resID, R.layout.spinner_item_style);
        subjectfont.setDropDownViewResource(R.layout.spinner_item_style);
        dropdown3.setAdapter(subjectfont);

        dropdown3.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                subject = dropdown3.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        dropdown4 = (Spinner)findViewById(R.id.sub_spinner4);
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, selectYear);
        dropdown4.setAdapter(adapter4);
        ArrayAdapter<CharSequence> yearfont = ArrayAdapter.createFromResource(this, R.array.yearList, R.layout.spinner_item_style);
        yearfont.setDropDownViewResource(R.layout.spinner_item_style);
        dropdown4.setAdapter(yearfont);

        dropdown4.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                year = dropdown4.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_activity2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);

    }

    public void DisplayQuesPaper(View view){

        Intent intend = new Intent(this, DisplayQuesPaper.class);
        intend.putExtra("finalbranch", branch);
        intend.putExtra("finalsemester", semester);
        intend.putExtra("finalsubject", subject);
        intend.putExtra("finalyear", year);
        this.startActivity(intend);

    }


}