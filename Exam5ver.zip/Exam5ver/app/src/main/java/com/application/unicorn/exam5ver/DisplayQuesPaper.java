package com.application.unicorn.exam5ver;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.URLUtil;
import android.webkit.WebView;
import android.widget.PopupWindow;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;


public class DisplayQuesPaper extends ActionBarActivity {

    public String finalCourse;
    public String finalBranch;
    public String finalSemester;
    public String finalSubject;
    public String finalYear;
    public String buildUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_quespaper);

        getSupportActionBar().hide();

        Intent intent = getIntent();
        //finalCourse = intent.getStringExtra("finalcourse");
        finalBranch = intent.getStringExtra("finalbranch");
        finalSemester = intent.getStringExtra("finalsemester");
        finalSubject = intent.getStringExtra("finalsubject");
        finalYear = intent.getStringExtra("finalyear");

        buildUrl = "http://unicornapp-unicornapp29.rhcloud.com/unicorn/Papers/"+"BE"+"/"+finalSemester+"/"+finalYear+"/"+finalSubject+".pdf";
        String finalURL = "https://docs.google.com/viewer?embedded=true&url="+buildUrl;
        System.out.println("URL to load:: " + finalURL);

        boolean filePresent = exists(buildUrl);
        if(filePresent == true){
            WebView myWebView = (WebView) findViewById(R.id.webview);
            setContentView(myWebView);
            myWebView.getSettings().setJavaScriptEnabled(true);

            myWebView.loadUrl(finalURL);
            setContentView(myWebView);
        }
        else
            //Toast.makeText(DisplayQuesPaper.this, "Question Paper for this Selection Does not Exists", Toast.LENGTH_LONG).show();
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Question Paper for this Selection Does not Exists");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    Intent intent1 = new Intent(getApplicationContext(), BePage.class);
                    startActivity(intent1);
                }
            });
            builder.create();
            builder.show();

        }





    }

    public static boolean exists(String buildUrl)
    {
        try
        {
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection conn = (HttpURLConnection) new URL(buildUrl).openConnection();
            conn.setRequestMethod("HEAD");
            return (conn.getResponseCode()== HttpURLConnection.HTTP_OK);

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_year_selection, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
